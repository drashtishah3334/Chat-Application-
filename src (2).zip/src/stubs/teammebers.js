export default{
	"amazon":[
		members:{'Ruhani','Sameer'}
	],
	"hsbc":[
		members:{'Zara','Malvika'}
	],
	"samsung":[
		members:{'Vikram','Aryan'}
	]
}