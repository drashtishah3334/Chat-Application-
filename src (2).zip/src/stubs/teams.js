export default{
	"amazon":{
		name:"Amazon"
	},
	"hsbc":{
		name:"HSBC"
	},
	"samsung":{
		name:"Samsung"
	}
}