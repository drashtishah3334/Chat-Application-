export default{
	"design":{
		name:"Design"
	},
	"development":{
		name:"Development"
	},
	"marketing":{
		name:"Marketing"
	},
	"testing":{
		name:"Testing"
	},
	"sales":{
		name:"Sales"
	}
}