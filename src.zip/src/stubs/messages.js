export default {
  "design": [
    {
      text: "Hello from design",
      sender: "Gopika",
      threadname:
    },
    
    {
      text: "Hello i m Dimple from design",
      sender: "Dimple",
      threadname:'redefinewebite'
    }
  ],
  "development": [
    {
      text: "Hello this is Vaibhavi from development",
      sender: "Vaibhavi",
      threadname:'createsignuppage'
    },
    {
      text: "Hello i m Yashu development team",
      sender: "Yashu",
      threadname:'exceptionhandling'
    },
    {
      text: "Team development",
      sender: "Gopika",
      threadname:'exceptionhandling'
    },
    {
      text: "Hello development team",
      sender: "Dimple",
      threadname:'createsignuppage'
    }
  ],
  "marketing": [
    {
      text: "Marketing Team",
      sender: "Siddharth",
      threadname:'createstrategies'
    },
    {
      text: "Hello i m Vaibhavi from marketing",
      sender: "Vaibhavi",
      threadname:'createstrategies'
    }
  ],
  "testing":[
    {
      text:"Testing Team",
      sender:"Dimple",
      threadname:'dounittesting'
    }
  ],
  "sales":[
    {
      text:"Sales Team",
      sender:"Vaibhavi",
      threadname:'reachgoal'
    }
  ]
}