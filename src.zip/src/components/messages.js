export default {
    "createlogo": [
      {
        text: "Hello",
        sender: "Kunal"
      },
      {
        text: "Hello",
        sender: "Ronak"
      },
      {
        text: "Whatsapp",
        sender: "Kunal"
      },
      {
        text: "nm",
        sender: "Ronak"
      }
    ],
    "redefinewebsite": [
        {
          text: "Hello",
          sender: "Kunal"
        },
        {
          text: "Hello",
          sender: "Sneha"
        },
        {
          text: "Whatsapp",
          sender: "Kunal"
        },
        {
          text: "just doing Vue",
          sender: "Sneha"
        }
      ],
      "createstrategies": [
        {
          text: "Hello",
          sender: "Kunal"
        },
        {
          text: "Hello",
          sender: "Drashti"
        },
        {
          text: "Whatsapp",
          sender: "Kunal"
        },
        {
          text: "just.....",
          sender: "Drashti"
        }
      ],
    }
