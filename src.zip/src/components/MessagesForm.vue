<template>
  <div class="message-form">
    <input class="input" placeholder="Enter your message..." v-model="message" @keyup.enter="sendMessage" :disabled="loading">
  </div>
</template>

<script>
  export default {
    name: 'message-form',
    data() {
      return {
        message: "",
        loading: false
      }
    },
    computed: {
      channelSlug() {
        return this.$route.params.slug
      }
    },
    methods: {
      sendMessage() {
        this.loading = true
        setTimeout(() => {
          let messageObj = {
            sender: "Kunal",
            text: this.message
          }
          this.$bus.$emit("message-sent:" + this.channelSlug, messageObj)
          this.loading = false
          this.message = ""
        }, 4000)
      }
    }
  }
</script>

<style lang="scss">
  .message-form {
    position: fixed;
    bottom: 0;
    right: 0;
    left: 200px;
    background: #fff;
    border-top: solid 1px #ddd;
    padding: 1rem;
    .input {
      border: solid 1px #ddd;
      border-radius: 3px;
      width: 100%;
      display: block;
      padding: 1rem;
      font-size: 1rem;
    }
  }
</style>
