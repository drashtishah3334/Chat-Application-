<template>
<div>
    <AppSidebar></AppSidebar>
    <app-messages></app-messages>
    <router-view></router-view>
</div>
</template>

<script>
import AppSidebar from '@/components/AppSidebar'
import AppMessages from '@/components/AppMessages'
export default {
    name: 'AppBase',
    components: {
        AppSidebar,
        AppMessages,
    }
}
</script>