export default{
    "design":{
        name:"Design"
    },
    "devlopment":{
        name:"Devlopment"
    },
    "marketing":{
        name:"Marketing"
    }
}